package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class TelaPrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_principal);
    }

    public void EnviarTelaInvestimentos(View view){
        Intent tela = new Intent(this, MeusInvestimentos.class);
        startActivity(tela);
    }

    public void sair(View view){
        Intent tela = new Intent(this, MainActivity.class);
        startActivity(tela);
    }



    public void abrirOportunidades(View view) {
        String url = "https://tcc-2024-info.vercel.app/";

        Intent intent = new Intent(Intent.ACTION_VIEW);
        Intent intent1 = intent.setData(Uri.parse(url));

        startActivity(intent);
    }

    public void abrirSuporte(View view) {
        String url = "https://tcc-2024-info.vercel.app/";

        Intent intent = new Intent(Intent.ACTION_VIEW);
        Intent intent1 = intent.setData(Uri.parse(url));

        startActivity(intent);
    }

    public void abrirMinhaConta(View view) {
        String url = "https://tcc-2024-info.vercel.app/";

        Intent intent = new Intent(Intent.ACTION_VIEW);
        Intent intent1 = intent.setData(Uri.parse(url));

        startActivity(intent);
    }
}